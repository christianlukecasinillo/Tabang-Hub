import Login from "./login/page";

export default function Home() {
  return (
    <>
      <Login/>
    </>
  );
}
