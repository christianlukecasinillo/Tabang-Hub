
import Navbar from "./components/Navbar";
import EditProfile from "./components/EditProfile";

export default function Home() {
  return (
    <>
      <Navbar />
      <EditProfile />
    </>
  );
}
