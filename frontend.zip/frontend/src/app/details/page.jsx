import React from 'react';
import { Typography, Box, Button } from '@mui/material';
import Image from 'next/image';
import Navbar from '../dashboard/components/Navbar';
import Link from 'next/link';

export default function CardDetails() {
    return (
        <>
            <Navbar />
            <Box 
                sx={{
                    borderRadius: '4rem 4rem 4rem 4rem',
                    backgroundColor: 'white',
                    mt: 15,
                    mx: 4,
                    p: 4,
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    flexDirection: 'column',  // Ensure the content stacks vertically
                    height: 'auto'
                }}
            >
                {/* Image Section */}
                <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', mb: 0 }}>
                        <Image
                            src="/images/logoTabangHub.png"
                            alt="Tabang Hub"
                            width={200}
                            height={300}
                            layout="intrinsic"
                        />
                </Box>

                {/* Text Content */}
                <Box sx={{ textAlign: 'center' }}> {/* Center text content */}
                    <Typography variant="h1" fontWeight="bold" gutterBottom sx={{ fontSize: { xs: '2rem', md: '3rem', lg: '4rem' } }}>
                        Connect <span>Serve</span> Community.
                    </Typography>
                    <Typography variant="body1" sx={{ mb: 3, maxWidth: '1000px', mx: 'auto' }}>
                        Help us in making a difference and ensuring the success of this event! Your abilities are essential to making a significant difference in our community. Come together with us to form stronger bonds and bring about positive change. If we work together, we can truly change things!
                    </Typography>
                    
                    {/* Buttons */}
                    <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2 }}>
                        <Button
                            variant="contained"
                            sx={{ backgroundColor: '#03b1fc', color: 'white', '&:hover': { backgroundColor: '#33f2b7' } }}
                        >
                            View Organization
                            <svg class="rtl:rotate-180 w-3.5 h-3.5 ms-2" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 10">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 5h12m0 0L9 1m4 4L9 9"/>
                            </svg>
                        </Button>
                        <Button
                            variant="outlined"
                            sx={{ borderColor: '#03b1fc', color: '#03b1fc', '&:hover': { backgroundColor: '#03b1fc', color: 'white' } }}
                        >
                            Apply Here
                            <svg class="rtl:rotate-180 w-3.5 h-3.5 ms-2" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 10">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 5h12m0 0L9 1m4 4L9 9"/>
                            </svg>
                        </Button>
                    </Box>
                </Box>
            </Box>
        </>
    );
}
